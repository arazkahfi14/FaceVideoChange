# Architecture

## Shared model

`filesDir/models/`

- det_10g.onnx
- w600k_r50.onnx
- inswapper_128.onnx
- emap.bin

PhotoActivity dan VideoProcessingService memakai ModelManager yang sama sehingga model hanya tersimpan satu kali.

## Photo

PhotoActivity -> FaceSwapEngine -> SCRFD -> ArcFace -> INSwapper -> ImageBlender -> MediaStore.

## Video

VideoActivity memilih media/range -> startForegroundService -> VideoProcessingService -> VideoFaceSwapProcessor -> MediaMetadataRetriever -> VideoFaceSwapEngine -> VideoEncoder -> MediaStore.

VideoProcessingService menyimpan progress di SharedPreferences dan mengirim broadcast package-local agar UI dapat menampilkan progress ketika aplikasi dibuka.
