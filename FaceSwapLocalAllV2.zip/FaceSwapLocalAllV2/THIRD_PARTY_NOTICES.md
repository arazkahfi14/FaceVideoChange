# Third-party notices

This project uses AndroidX, Material Components, AndroidX ExifInterface, Microsoft ONNX Runtime, and an InsightFace-style face-analysis / face-swap pipeline.

The application source code and pretrained AI models can have different licenses. The model download URLs included in ModelManager are not a grant of commercial rights. Review the applicable model terms before redistribution or commercial use.
