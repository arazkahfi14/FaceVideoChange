# V1 debug/personal build: no custom ProGuard rules required.
