package com.local.faceswapall;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public final class ImageBlender {
    private ImageBlender() {}

    public static Bitmap blend(Bitmap target, Bitmap swapped128, Matrix sourceToCrop) {
        int w = swapped128.getWidth();
        int h = swapped128.getHeight();

        int[] pixels = new int[w * h];
        swapped128.getPixels(pixels, 0, w, 0, 0, w, h);

        for (int y = 0; y < h; y++) {
            float ny = (y - h * 0.50f) / (h * 0.48f);
            for (int x = 0; x < w; x++) {
                float nx = (x - w * 0.50f) / (w * 0.43f);
                float d = (float) Math.sqrt(nx * nx + ny * ny);

                float a;
                if (d <= 0.64f) a = 1f;
                else if (d >= 1f) a = 0f;
                else {
                    float t = (1f - d) / 0.36f;
                    t = Math.max(0f, Math.min(1f, t));
                    a = t * t * (3f - 2f * t);
                }

                int idx = y * w + x;
                int rgb = pixels[idx] & 0x00FFFFFF;
                int alpha = Math.max(0, Math.min(255, Math.round(a * 255f)));
                pixels[idx] = (alpha << 24) | rgb;
            }
        }

        Bitmap masked = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        masked.setPixels(pixels, 0, w, 0, 0, w, h);

        Bitmap output = target.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(output);

        Matrix cropToSource = new Matrix();
        if (!sourceToCrop.invert(cropToSource)) {
            throw new IllegalStateException("Gagal membalik matriks alignment.");
        }

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(masked, cropToSource, paint);
        masked.recycle();

        return output;
    }
}
