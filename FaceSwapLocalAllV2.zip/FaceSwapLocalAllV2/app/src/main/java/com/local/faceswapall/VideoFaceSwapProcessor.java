package com.local.faceswapall;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VideoFaceSwapProcessor {
    public interface Callback {
        void onStatus(String status);
        void onProgress(int percent, int frame, int totalFrames);
    }

    public static final long MAX_CLIP_DURATION_US = 30_000_000L;

    private VideoFaceSwapProcessor() {}

    public static File process(
            Context context,
            Uri sourceUri,
            Uri videoUri,
            ModelManager models,
            long requestedStartUs,
            long requestedEndUs,
            boolean quality,
            AtomicBoolean cancelled,
            Callback callback
    ) throws Exception {
        int fps = quality ? 15 : 10;
        int maxLongSide = quality ? 960 : 720;
        int bitrate = quality ? 6_000_000 : 3_500_000;

        callback.onStatus("Membaca foto wajah...");
        Bitmap source = ImageLoader.load(context, sourceUri, 1280);

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(context, videoUri);

        long durationUs = readDurationUs(retriever);
        long startUs = Math.max(0L, Math.min(requestedStartUs, Math.max(0L, durationUs - 1L)));
        long endUs = Math.max(startUs + 1L, Math.min(requestedEndUs, durationUs));
        if (endUs - startUs > MAX_CLIP_DURATION_US) endUs = startUs + MAX_CLIP_DURATION_US;
        long workDurationUs = endUs - startUs;
        if (workDurationUs < 500_000L) {
            source.recycle();
            retriever.release();
            throw new IllegalArgumentException("Bagian video minimal 0,5 detik.");
        }
        int rotation = readInt(retriever, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION, 0);

        Bitmap probe = retriever.getFrameAtTime(startUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        if (probe == null) {
            source.recycle();
            retriever.release();
            throw new IllegalStateException("Video tidak bisa dibaca oleh decoder Android.");
        }
        probe = rotate(probe, rotation);
        int[] outSize = fitEven(probe.getWidth(), probe.getHeight(), maxLongSide);
        int outW = outSize[0];
        int outH = outSize[1];
        probe.recycle();

        File temp = new File(context.getCacheDir(), "faceswap_video_" + System.currentTimeMillis() + ".mp4");
        if (temp.exists()) temp.delete();

        MediaExtractor audioExtractor = new MediaExtractor();
        audioExtractor.setDataSource(context, videoUri, null);
        int audioTrackIndex = findAudioTrack(audioExtractor);
        MediaFormat audioFormat = audioTrackIndex >= 0 ? audioExtractor.getTrackFormat(audioTrackIndex) : null;

        long frameIntervalUs = 1_000_000L / fps;
        int totalFrames = Math.max(1, (int) Math.ceil(workDurationUs / (double) frameIntervalUs));

        callback.onStatus("Menyiapkan engine wajah...");
        try (VideoFaceSwapEngine engine = new VideoFaceSwapEngine(models, source);
             VideoEncoder encoder = new VideoEncoder(temp, outW, outH, fps, bitrate, audioFormat)) {

            source.recycle();
            source = null;

            Bitmap previous = null;
            for (int i = 0; i < totalFrames; i++) {
                if (cancelled.get()) throw new InterruptedException("Proses dibatalkan.");

                long outputPts = Math.min(i * frameIntervalUs, Math.max(0L, workDurationUs - 1L));
                long sourcePts = startUs + outputPts;
                Bitmap raw = retriever.getFrameAtTime(sourcePts, MediaMetadataRetriever.OPTION_CLOSEST);
                if (raw != null) raw = rotate(raw, rotation);

                Bitmap frame;
                if (raw == null) {
                    if (previous == null) continue;
                    frame = previous.copy(Bitmap.Config.ARGB_8888, false);
                } else {
                    frame = scaleExact(raw, outW, outH);
                    if (frame != raw) raw.recycle();
                }

                callback.onStatus("Face swap frame " + (i + 1) + " / " + totalFrames + "...");
                Bitmap processed = engine.processFrame(frame);

                encoder.encode(processed, outputPts);

                if (previous != null && !previous.isRecycled()) previous.recycle();
                previous = processed.copy(Bitmap.Config.ARGB_8888, false);

                if (processed != frame && !processed.isRecycled()) processed.recycle();
                if (!frame.isRecycled()) frame.recycle();

                int percent = Math.min(95, Math.round((i + 1) * 95f / totalFrames));
                callback.onProgress(percent, i + 1, totalFrames);
            }

            if (previous != null && !previous.isRecycled()) previous.recycle();

            callback.onStatus("Finalisasi video...");
            encoder.finish(workDurationUs);
            encoder.copyAudio(audioExtractor, audioTrackIndex, startUs, endUs);
            callback.onProgress(100, totalFrames, totalFrames);
        } catch (Exception e) {
            if (source != null && !source.isRecycled()) source.recycle();
            if (temp.exists()) temp.delete();
            throw e;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
            try { audioExtractor.release(); } catch (Exception ignored) {}
            if (source != null && !source.isRecycled()) source.recycle();
        }

        if (!temp.exists() || temp.length() < 10_000L) {
            throw new IllegalStateException("File output gagal dibuat.");
        }
        return temp;
    }

    public static String describe(Context context, Uri videoUri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(context, videoUri);
            long durationMs = readDurationUs(r) / 1000L;
            int w = readInt(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH, 0);
            int h = readInt(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT, 0);
            int rot = readInt(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION, 0);
            if (rot == 90 || rot == 270) { int t = w; w = h; h = t; }
            return String.format(java.util.Locale.US, "%dx%d • %.1f detik • pilih bagian maksimal 30 detik",
                    w, h, durationMs / 1000f);
        } catch (Exception e) {
            return "Video dipilih.";
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    public static float durationSeconds(Context context, Uri videoUri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(context, videoUri);
            return readDurationUs(r) / 1_000_000f;
        } catch (Exception e) {
            return 0f;
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    public static Bitmap thumbnail(Context context, Uri videoUri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(context, videoUri);
            int rot = readInt(r, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION, 0);
            Bitmap b = r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (b == null) return null;
            b = rotate(b, rot);
            int[] s = fitEven(b.getWidth(), b.getHeight(), 720);
            Bitmap scaled = scaleExact(b, s[0], s[1]);
            if (scaled != b) b.recycle();
            return scaled;
        } catch (Exception e) {
            return null;
        } finally {
            try { r.release(); } catch (Exception ignored) {}
        }
    }

    private static long readDurationUs(MediaMetadataRetriever r) {
        String s = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        if (s == null) return 0L;
        return Math.max(1L, Long.parseLong(s)) * 1000L;
    }

    private static int readInt(MediaMetadataRetriever r, int key, int fallback) {
        try {
            String s = r.extractMetadata(key);
            return s == null ? fallback : Integer.parseInt(s);
        } catch (Exception e) {
            return fallback;
        }
    }

    private static int findAudioTrack(MediaExtractor extractor) {
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat f = extractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) return i;
        }
        return -1;
    }

    private static int[] fitEven(int w, int h, int maxLongSide) {
        float scale = Math.min(1f, maxLongSide / (float) Math.max(w, h));
        int nw = Math.max(2, Math.round(w * scale));
        int nh = Math.max(2, Math.round(h * scale));
        if ((nw & 1) != 0) nw--;
        if ((nh & 1) != 0) nh--;
        return new int[]{Math.max(2, nw), Math.max(2, nh)};
    }

    private static Bitmap scaleExact(Bitmap src, int w, int h) {
        if (src.getWidth() == w && src.getHeight() == h && src.getConfig() == Bitmap.Config.ARGB_8888) return src;
        Bitmap out = Bitmap.createScaledBitmap(src, w, h, true);
        if (out.getConfig() != Bitmap.Config.ARGB_8888) {
            Bitmap copy = out.copy(Bitmap.Config.ARGB_8888, false);
            if (copy != out) out.recycle();
            out = copy;
        }
        return out;
    }

    private static Bitmap rotate(Bitmap src, int degrees) {
        if (degrees % 360 == 0) return src;
        Matrix m = new Matrix();
        m.postRotate(degrees);
        Bitmap out = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
        if (out != src) src.recycle();
        return out;
    }
}
