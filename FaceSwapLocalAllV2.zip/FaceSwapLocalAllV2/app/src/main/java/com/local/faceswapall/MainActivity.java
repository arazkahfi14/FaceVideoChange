package com.local.faceswapall;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private TextView txtHomeModelStatus;
    private TextView txtBackgroundStatus;
    private ProgressBar homeVideoProgress;
    private LinearLayout cardBackgroundStatus;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean running = intent.getBooleanExtra(VideoProcessingService.EXTRA_RUNNING, false);
            int progress = intent.getIntExtra(VideoProcessingService.EXTRA_PROGRESS, 0);
            String status = intent.getStringExtra(VideoProcessingService.EXTRA_STATUS);
            renderVideoState(running, progress, status);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txtHomeModelStatus = findViewById(R.id.txtHomeModelStatus);
        txtBackgroundStatus = findViewById(R.id.txtBackgroundStatus);
        homeVideoProgress = findViewById(R.id.homeVideoProgress);
        cardBackgroundStatus = findViewById(R.id.cardBackgroundStatus);
        MaterialButton btnPhoto = findViewById(R.id.btnPhotoMode);
        MaterialButton btnVideo = findViewById(R.id.btnVideoMode);

        btnPhoto.setOnClickListener(v -> startActivity(new Intent(this, PhotoActivity.class)));
        btnVideo.setOnClickListener(v -> startActivity(new Intent(this, VideoActivity.class)));
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                    this,
                    receiver,
                    new IntentFilter(VideoProcessingService.ACTION_PROGRESS),
                    ContextCompat.RECEIVER_NOT_EXPORTED
            );
            receiverRegistered = true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ModelManager models = new ModelManager(this);
        if (models.isReady()) {
            txtHomeModelStatus.setText("✓ Model AI siap • dipakai Foto & Video");
        } else {
            long mb = models.currentBytes() / (1024L * 1024L);
            txtHomeModelStatus.setText(mb > 0
                    ? "Model belum lengkap • " + mb + " MB tersimpan"
                    : "Model belum diunduh • buka Foto atau Video untuk download");
        }

        VideoProcessingService.JobState state = VideoProcessingService.readState(this);
        renderVideoState(state.running, state.progress, state.status);
    }

    private void renderVideoState(boolean running, int progress, String status) {
        if (running) {
            cardBackgroundStatus.setVisibility(View.VISIBLE);
            homeVideoProgress.setProgress(progress);
            txtBackgroundStatus.setText(progress + "% • " + (status == null ? "Memproses..." : status));
        } else {
            cardBackgroundStatus.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStop() {
        if (receiverRegistered) {
            unregisterReceiver(receiver);
            receiverRegistered = false;
        }
        super.onStop();
    }
}
