package com.local.faceswapall;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.slider.RangeSlider;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VideoActivity extends AppCompatActivity {
    private static final int REQ_SOURCE = 2001;
    private static final int REQ_VIDEO = 2002;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean receiverRegistered = false;

    private final BroadcastReceiver progressReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            applyJobState(
                    intent.getBooleanExtra(VideoProcessingService.EXTRA_RUNNING, false),
                    intent.getIntExtra(VideoProcessingService.EXTRA_PROGRESS, 0),
                    intent.getStringExtra(VideoProcessingService.EXTRA_STATUS),
                    intent.getStringExtra(VideoProcessingService.EXTRA_RESULT_URI)
            );
        }
    };

    private ModelManager models;
    private Uri sourceUri;
    private Uri videoUri;
    private Bitmap videoThumb;

    private TextView txtModelStatus, txtDownloadDetail, txtVideoInfo, txtClipRange, txtClipDuration, txtProcessStatus, txtSavedPath;
    private ProgressBar modelProgress, processProgress;
    private Button btnModel, btnDeleteModel, btnSource, btnVideo, btnProcess, btnCancel;
    private ImageView imgSource, imgVideoThumb;
    private MaterialCheckBox checkQuality;
    private RangeSlider rangeClip;
    private LinearLayout clipCard, resultCard;
    private VideoView videoResult;

    private float videoDurationSec = 0f;
    private float selectedStartSec = 0f;
    private float selectedEndSec = 0f;
    private float previousStartSec = 0f;
    private float previousEndSec = 0f;
    private boolean updatingClipRange = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        models = new ModelManager(this);
        bindViews();
        bindActions();
        refreshModelUi();
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4103);
        }
    }

    private void bindViews() {
        txtModelStatus = findViewById(R.id.txtModelStatus);
        txtDownloadDetail = findViewById(R.id.txtDownloadDetail);
        txtVideoInfo = findViewById(R.id.txtVideoInfo);
        txtClipRange = findViewById(R.id.txtClipRange);
        txtClipDuration = findViewById(R.id.txtClipDuration);
        txtProcessStatus = findViewById(R.id.txtProcessStatus);
        txtSavedPath = findViewById(R.id.txtSavedPath);
        modelProgress = findViewById(R.id.modelProgress);
        processProgress = findViewById(R.id.processProgress);
        btnModel = findViewById(R.id.btnModel);
        btnDeleteModel = findViewById(R.id.btnDeleteModel);
        btnSource = findViewById(R.id.btnSource);
        btnVideo = findViewById(R.id.btnVideo);
        btnProcess = findViewById(R.id.btnProcess);
        btnCancel = findViewById(R.id.btnCancel);
        imgSource = findViewById(R.id.imgSource);
        imgVideoThumb = findViewById(R.id.imgVideoThumb);
        checkQuality = findViewById(R.id.checkQuality);
        rangeClip = findViewById(R.id.rangeClip);
        clipCard = findViewById(R.id.clipCard);
        resultCard = findViewById(R.id.resultCard);
        videoResult = findViewById(R.id.videoResult);
    }

    private void bindActions() {
        btnModel.setOnClickListener(v -> downloadModels());
        btnDeleteModel.setOnClickListener(v -> {
            models.deleteAll();
            refreshModelUi();
            Toast.makeText(this, "Model dihapus.", Toast.LENGTH_SHORT).show();
        });
        btnSource.setOnClickListener(v -> choose("image/*", REQ_SOURCE));
        btnVideo.setOnClickListener(v -> choose("video/*", REQ_VIDEO));
        btnProcess.setOnClickListener(v -> runVideoSwap());
        btnCancel.setOnClickListener(v -> {
            Intent cancel = new Intent(this, VideoProcessingService.class);
            cancel.setAction(VideoProcessingService.ACTION_CANCEL);
            startService(cancel);
            txtProcessStatus.setText("Membatalkan setelah frame aktif selesai...");
        });
        rangeClip.addOnChangeListener((slider, value, fromUser) -> {
            if (updatingClipRange) return;
            java.util.List<Float> values = slider.getValues();
            if (values.size() < 2) return;

            float start = values.get(0);
            float end = values.get(1);
            if (end - start > 30f) {
                boolean startMoved = Math.abs(start - previousStartSec) >= Math.abs(end - previousEndSec);
                if (startMoved) start = Math.max(0f, end - 30f);
                else end = Math.min(videoDurationSec, start + 30f);

                updatingClipRange = true;
                slider.setValues(start, end);
                updatingClipRange = false;
            }

            selectedStartSec = start;
            selectedEndSec = end;
            previousStartSec = start;
            previousEndSec = end;
            updateClipUi();
            refreshProcessButton();
        });
    }

    private void choose(String type, int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        if (requestCode == REQ_SOURCE) {
            sourceUri = uri;
            imgSource.setImageURI(uri);
        } else if (requestCode == REQ_VIDEO) {
            videoUri = uri;
            txtVideoInfo.setText(VideoFaceSwapProcessor.describe(this, uri));
            configureClipRange(uri);
            if (videoThumb != null && !videoThumb.isRecycled()) videoThumb.recycle();
            videoThumb = VideoFaceSwapProcessor.thumbnail(this, uri);
            if (videoThumb != null) imgVideoThumb.setImageBitmap(videoThumb);
        }
        refreshProcessButton();
    }

    private void refreshModelUi() {
        boolean ready = models.isReady();
        long mb = models.currentBytes() / (1024L * 1024L);
        if (ready) {
            txtModelStatus.setText("✓ Model AI siap (" + mb + " MB)");
            txtDownloadDetail.setVisibility(View.GONE);
            modelProgress.setVisibility(View.GONE);
            btnModel.setVisibility(View.GONE);
            btnDeleteModel.setVisibility(View.VISIBLE);
        } else {
            txtModelStatus.setText("Model AI belum lengkap");
            txtDownloadDetail.setText(mb > 0
                    ? "Sudah tersimpan " + mb + " MB. Download bisa dilanjutkan."
                    : "Download pertama ±740 MB. Setelah itu bisa offline.");
            txtDownloadDetail.setVisibility(View.VISIBLE);
            btnModel.setVisibility(View.VISIBLE);
            btnModel.setEnabled(true);
            btnDeleteModel.setVisibility(mb > 0 ? View.VISIBLE : View.GONE);
            modelProgress.setVisibility(View.GONE);
        }
        refreshProcessButton();
    }

    private void refreshProcessButton() {
        boolean validRange = selectedEndSec - selectedStartSec >= 0.5f;
        boolean running = VideoProcessingService.readState(this).running;
        btnProcess.setEnabled(models.isReady() && sourceUri != null && videoUri != null && validRange && !running);
    }

    private void configureClipRange(Uri uri) {
        videoDurationSec = VideoFaceSwapProcessor.durationSeconds(this, uri);
        if (videoDurationSec <= 0f) {
            clipCard.setVisibility(View.GONE);
            selectedStartSec = 0f;
            selectedEndSec = 0f;
            return;
        }

        float sliderMax = Math.max(1f, videoDurationSec);
        selectedStartSec = 0f;
        selectedEndSec = Math.min(30f, videoDurationSec);
        previousStartSec = selectedStartSec;
        previousEndSec = selectedEndSec;

        updatingClipRange = true;
        rangeClip.setValueFrom(0f);
        rangeClip.setValueTo(sliderMax);
        rangeClip.setValues(selectedStartSec, selectedEndSec);
        rangeClip.setEnabled(true);
        updatingClipRange = false;
        clipCard.setVisibility(View.VISIBLE);
        updateClipUi();
    }

    private void updateClipUi() {
        float length = Math.max(0f, selectedEndSec - selectedStartSec);
        txtClipRange.setText(formatTime(selectedStartSec) + "  →  " + formatTime(selectedEndSec));
        txtClipDuration.setText(String.format(Locale.US, "Bagian dipilih: %.1f detik • maksimal 30 detik", length));
    }

    private static String formatTime(float seconds) {
        int total = Math.max(0, Math.round(seconds));
        int h = total / 3600;
        int m = (total % 3600) / 60;
        int s = total % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    private void downloadModels() {
        btnModel.setEnabled(false);
        btnDeleteModel.setEnabled(false);
        modelProgress.setVisibility(View.VISIBLE);
        txtDownloadDetail.setVisibility(View.VISIBLE);
        txtModelStatus.setText("Mengunduh model AI...");

        executor.execute(() -> models.downloadAll(new ModelManager.Listener() {
            @Override
            public void onProgress(String fileName, int overallPercent, long doneBytes, long totalBytes) {
                runOnUiThread(() -> {
                    modelProgress.setProgress(overallPercent);
                    txtDownloadDetail.setText(friendlyName(fileName) + " • " + overallPercent + "% • " + mb(doneBytes) + " / " + mb(totalBytes) + " MB");
                });
            }

            @Override
            public void onComplete() {
                runOnUiThread(() -> {
                    btnDeleteModel.setEnabled(true);
                    Toast.makeText(VideoActivity.this, "Model siap. Setelah ini bisa offline.", Toast.LENGTH_LONG).show();
                    refreshModelUi();
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    btnModel.setEnabled(true);
                    btnDeleteModel.setEnabled(true);
                    txtModelStatus.setText("Download gagal");
                    txtDownloadDetail.setText(message + "\nTekan Download Model AI untuk melanjutkan.");
                });
            }
        }));
    }

    private void runVideoSwap() {
        if (!models.isReady() || sourceUri == null || videoUri == null) return;

        long startUs = Math.round(selectedStartSec * 1_000_000d);
        long endUs = Math.round(selectedEndSec * 1_000_000d);

        Intent service = new Intent(this, VideoProcessingService.class);
        service.setAction(VideoProcessingService.ACTION_START);
        service.putExtra(VideoProcessingService.EXTRA_SOURCE_URI, sourceUri.toString());
        service.putExtra(VideoProcessingService.EXTRA_VIDEO_URI, videoUri.toString());
        service.putExtra(VideoProcessingService.EXTRA_START_US, startUs);
        service.putExtra(VideoProcessingService.EXTRA_END_US, endUs);
        service.putExtra(VideoProcessingService.EXTRA_QUALITY, checkQuality.isChecked());

        resultCard.setVisibility(View.GONE);
        processProgress.setProgress(0);
        txtProcessStatus.setText("Menyiapkan video...");
        setProcessing(true);
        startForegroundService(service);
    }

    private void applyJobState(boolean running, int progress, String status, String resultUri) {
        processProgress.setProgress(progress);
        if (status != null && !status.isEmpty()) txtProcessStatus.setText(status);
        setProcessing(running);

        if (!running && resultUri != null && !resultUri.isEmpty()) {
            try {
                Uri uri = Uri.parse(resultUri);
                txtSavedPath.setText("Movies/FaceSwapLocal");
                resultCard.setVisibility(View.VISIBLE);
                MediaController controller = new MediaController(VideoActivity.this);
                controller.setAnchorView(videoResult);
                videoResult.setMediaController(controller);
                videoResult.setVideoURI(uri);
                videoResult.seekTo(1);
            } catch (Exception ignored) {}
        }
    }

    private void restoreJobState() {
        VideoProcessingService.JobState state = VideoProcessingService.readState(this);
        applyJobState(state.running, state.progress, state.status, state.resultUri);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter(VideoProcessingService.ACTION_PROGRESS);
            ContextCompat.registerReceiver(this, progressReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }
        restoreJobState();
    }

    @Override
    protected void onStop() {
        if (receiverRegistered) {
            unregisterReceiver(progressReceiver);
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void setProcessing(boolean processing) {
        btnSource.setEnabled(!processing);
        btnVideo.setEnabled(!processing);
        btnDeleteModel.setEnabled(!processing);
        checkQuality.setEnabled(!processing);
        rangeClip.setEnabled(!processing && videoUri != null);
        processProgress.setVisibility(processing ? View.VISIBLE : View.GONE);
        btnCancel.setVisibility(processing ? View.VISIBLE : View.GONE);
        if (!processing) refreshProcessButton();
        else btnProcess.setEnabled(false);
    }

    private static long mb(long bytes) {
        return Math.max(0L, bytes / (1024L * 1024L));
    }

    private static String friendlyName(String file) {
        if (ModelManager.DETECTOR.equals(file)) return "Detector";
        if (ModelManager.EMBEDDER.equals(file)) return "ArcFace";
        if (ModelManager.SWAPPER.equals(file)) return "INSwapper";
        if (ModelManager.EMAP.equals(file)) return "EMAP";
        return file;
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (videoThumb != null && !videoThumb.isRecycled()) videoThumb.recycle();
        super.onDestroy();
    }
}
