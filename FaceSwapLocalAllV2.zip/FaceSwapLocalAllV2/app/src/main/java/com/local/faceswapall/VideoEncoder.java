package com.local.faceswapall;

import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import java.io.File;
import java.nio.ByteBuffer;

public final class VideoEncoder implements AutoCloseable {
    private static final long TIMEOUT_US = 20_000L;

    private final MediaCodec encoder;
    private final MediaMuxer muxer;
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private final MediaFormat audioFormat;
    private final int width;
    private final int height;

    private int videoTrack = -1;
    private int audioTrack = -1;
    private boolean muxerStarted = false;
    private boolean finished = false;

    public VideoEncoder(File output, int width, int height, int frameRate, int bitrate, MediaFormat audioFormat) throws Exception {
        this.width = width;
        this.height = height;
        this.audioFormat = audioFormat;

        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, frameRate);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);

        encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        encoder.start();

        muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
    }

    public void encode(Bitmap bitmap, long ptsUs) throws Exception {
        if (bitmap.getWidth() != width || bitmap.getHeight() != height) {
            throw new IllegalArgumentException("Ukuran frame berubah saat encoding.");
        }

        int inputIndex;
        while ((inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US)) < 0) {
            drain(false);
        }

        Image inputImage = encoder.getInputImage(inputIndex);
        if (inputImage == null) {
            throw new IllegalStateException("Encoder HP tidak menyediakan input YUV Image.");
        }

        try {
            BitmapYuvWriter.write(bitmap, inputImage);
        } finally {
            inputImage.close();
        }

        int size = width * height * 3 / 2;
        encoder.queueInputBuffer(inputIndex, 0, size, ptsUs, 0);
        drain(false);
    }

    public void finish(long ptsUs) throws Exception {
        if (finished) return;
        int inputIndex;
        do {
            inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
            if (inputIndex < 0) drain(false);
        } while (inputIndex < 0);

        encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
        drain(true);
        finished = true;
    }

    private void drain(boolean end) throws Exception {
        while (true) {
            int outIndex = encoder.dequeueOutputBuffer(info, end ? TIMEOUT_US : 0L);

            if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) return;
                continue;
            }

            if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new IllegalStateException("Format video berubah dua kali.");
                videoTrack = muxer.addTrack(encoder.getOutputFormat());
                if (audioFormat != null) {
                    try { audioTrack = muxer.addTrack(audioFormat); }
                    catch (Exception ignored) { audioTrack = -1; }
                }
                muxer.start();
                muxerStarted = true;
                continue;
            }

            if (outIndex >= 0) {
                ByteBuffer buffer = encoder.getOutputBuffer(outIndex);
                if (buffer == null) throw new IllegalStateException("Output encoder kosong.");

                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;

                if (info.size > 0) {
                    if (!muxerStarted) throw new IllegalStateException("Muxer belum siap.");
                    buffer.position(info.offset);
                    buffer.limit(info.offset + info.size);
                    muxer.writeSampleData(videoTrack, buffer, info);
                }

                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                encoder.releaseOutputBuffer(outIndex, false);
                if (eos) return;
            }
        }
    }

    public void copyAudio(MediaExtractor extractor, int extractorAudioTrack, long sourceStartUs, long sourceEndUs) throws Exception {
        if (!muxerStarted || audioTrack < 0 || extractorAudioTrack < 0) return;
        extractor.selectTrack(extractorAudioTrack);
        extractor.seekTo(sourceStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

        int max = 1024 * 1024;
        MediaFormat f = extractor.getTrackFormat(extractorAudioTrack);
        if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
            max = Math.max(max, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
        }

        ByteBuffer buffer = ByteBuffer.allocateDirect(max);
        MediaCodec.BufferInfo audioInfo = new MediaCodec.BufferInfo();

        while (true) {
            long sampleTime = extractor.getSampleTime();
            if (sampleTime < 0 || sampleTime >= sourceEndUs) break;
            if (sampleTime < sourceStartUs) {
                extractor.advance();
                continue;
            }

            buffer.clear();
            int size = extractor.readSampleData(buffer, 0);
            if (size < 0) break;

            audioInfo.offset = 0;
            audioInfo.size = size;
            audioInfo.presentationTimeUs = Math.max(0L, sampleTime - sourceStartUs);
            audioInfo.flags = extractor.getSampleFlags();
            buffer.position(0);
            buffer.limit(size);
            muxer.writeSampleData(audioTrack, buffer, audioInfo);
            extractor.advance();
        }

        extractor.unselectTrack(extractorAudioTrack);
    }

    @Override
    public void close() {
        try { encoder.stop(); } catch (Exception ignored) {}
        try { encoder.release(); } catch (Exception ignored) {}
        if (muxerStarted) {
            try { muxer.stop(); } catch (Exception ignored) {}
        }
        try { muxer.release(); } catch (Exception ignored) {}
    }
}
