package com.local.faceswapall;

import android.graphics.Bitmap;

import java.nio.FloatBuffer;
import java.util.Collections;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

public final class FaceEmbedder implements AutoCloseable {

    private static final int SIZE = 112;
    private final OrtEnvironment env = OrtEnvironment.getEnvironment();
    private OrtSession session;

    public FaceEmbedder(ModelManager models) throws Exception {
        session = OrtUtils.createSession(env, models.getFile(ModelManager.EMBEDDER).getAbsolutePath());
    }

    public float[] embedding(Bitmap alignedFace) throws Exception {
        Bitmap face = alignedFace.getWidth() == SIZE && alignedFace.getHeight() == SIZE
                ? alignedFace
                : Bitmap.createScaledBitmap(alignedFace, SIZE, SIZE, true);

        int count = SIZE * SIZE;
        int[] pixels = new int[count];
        face.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE);

        float[] chw = new float[count * 3];
        for (int i = 0; i < count; i++) {
            int c = pixels[i];
            int r = (c >> 16) & 255;
            int g = (c >> 8) & 255;
            int b = c & 255;
            chw[i] = (r - 127.5f) / 127.5f;
            chw[count + i] = (g - 127.5f) / 127.5f;
            chw[count * 2 + i] = (b - 127.5f) / 127.5f;
        }

        OnnxTensor tensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(chw), new long[]{1, 3, SIZE, SIZE});

        String inputName = session.getInputNames().iterator().next();
        OrtSession.Result result = session.run(Collections.singletonMap(inputName, tensor));
        float[][] raw = (float[][]) result.get(0).getValue();
        float[] normalized = l2(raw[0]);

        result.close();
        tensor.close();
        if (face != alignedFace) face.recycle();

        return normalized;
    }

    private static float[] l2(float[] x) {
        float norm = 0f;
        for (float v : x) norm += v * v;
        norm = (float) Math.sqrt(norm);
        if (norm <= 0f) return x;

        float[] out = new float[x.length];
        for (int i = 0; i < x.length; i++) out[i] = x[i] / norm;
        return out;
    }

    @Override
    public void close() {
        if (session != null) {
            try { session.close(); } catch (Exception ignored) {}
            session = null;
        }
    }
}
