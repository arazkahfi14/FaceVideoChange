package com.local.faceswapall;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ModelManager {

    public interface Listener {
        void onProgress(String fileName, int overallPercent, long doneBytes, long totalBytes);
        void onComplete();
        void onError(String message);
    }

    public static final String DETECTOR = "det_10g.onnx";
    public static final String EMBEDDER = "w600k_r50.onnx";
    public static final String SWAPPER = "inswapper_128.onnx";
    public static final String EMAP = "emap.bin";

    private static final long MB = 1024L * 1024L;

    private static final class Spec {
        final String url;
        final long expectedBytes;
        final long minBytes;

        Spec(String url, long expectedBytes, long minBytes) {
            this.url = url;
            this.expectedBytes = expectedBytes;
            this.minBytes = minBytes;
        }
    }

    private final Context context;
    private final File modelDir;
    private final LinkedHashMap<String, Spec> specs = new LinkedHashMap<>();

    public ModelManager(Context context) {
        this.context = context.getApplicationContext();
        this.modelDir = new File(this.context.getFilesDir(), "models");
        if (!modelDir.exists()) {
            modelDir.mkdirs();
        }

        specs.put(DETECTOR, new Spec(
                "https://huggingface.co/leonelhs/insightface/resolve/main/det_10g.onnx",
                16L * MB, 10L * MB));

        specs.put(EMBEDDER, new Spec(
                "https://huggingface.co/leonelhs/insightface/resolve/main/w600k_r50.onnx",
                166L * MB, 100L * MB));

        specs.put(SWAPPER, new Spec(
                "https://huggingface.co/leonelhs/insightface/resolve/main/inswapper_128.onnx",
                554L * MB, 500L * MB));

        specs.put(EMAP, new Spec(
                "https://raw.githubusercontent.com/Parasaran-Python/android-face-fusion/refs/heads/master/app/src/main/assets/emap.bin",
                1_048_584L, 1_048_000L));
    }

    public File getFile(String name) {
        return new File(modelDir, name);
    }

    public boolean isReady() {
        for (Map.Entry<String, Spec> entry : specs.entrySet()) {
            File f = getFile(entry.getKey());
            if (!f.exists() || f.length() < entry.getValue().minBytes) {
                return false;
            }
        }
        return true;
    }

    public long currentBytes() {
        long size = 0L;
        for (String name : specs.keySet()) {
            File f = getFile(name);
            if (f.exists()) size += f.length();
        }
        return size;
    }

    public long expectedTotalBytes() {
        long total = 0L;
        for (Spec spec : specs.values()) total += spec.expectedBytes;
        return total;
    }

    public void deleteAll() {
        for (String name : specs.keySet()) {
            File f = getFile(name);
            if (f.exists()) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        }
    }

    public void downloadAll(Listener listener) {
        try {
            long completedBeforeCurrent = 0L;
            long expectedTotal = expectedTotalBytes();

            for (Map.Entry<String, Spec> entry : specs.entrySet()) {
                String name = entry.getKey();
                Spec spec = entry.getValue();
                File out = getFile(name);

                if (out.exists() && out.length() >= spec.minBytes) {
                    completedBeforeCurrent += spec.expectedBytes;
                    int p = (int) Math.min(100L, completedBeforeCurrent * 100L / expectedTotal);
                    listener.onProgress(name, p, completedBeforeCurrent, expectedTotal);
                    continue;
                }

                downloadWithResume(name, spec, out, completedBeforeCurrent, expectedTotal, listener);
                completedBeforeCurrent += spec.expectedBytes;
            }

            if (!isReady()) {
                throw new IllegalStateException("Download selesai tetapi ada model yang tidak lengkap.");
            }

            listener.onProgress("Selesai", 100, expectedTotal, expectedTotal);
            listener.onComplete();
        } catch (Exception e) {
            listener.onError(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    private void downloadWithResume(
            String name,
            Spec spec,
            File outputFile,
            long completedBeforeCurrent,
            long expectedTotal,
            Listener listener
    ) throws Exception {

        int maxAttempts = 5;
        Exception last = null;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                downloadAttempt(name, spec, outputFile, completedBeforeCurrent, expectedTotal, listener);
                if (outputFile.length() < spec.minBytes) {
                    throw new IllegalStateException(name + " belum lengkap (" + outputFile.length() + " byte)");
                }
                return;
            } catch (Exception e) {
                last = e;
                if (attempt < maxAttempts) {
                    Thread.sleep(1200L * attempt);
                }
            }
        }

        throw new Exception("Gagal download " + name + ": " +
                (last != null && last.getMessage() != null ? last.getMessage() : "unknown error"));
    }

    private void downloadAttempt(
            String name,
            Spec spec,
            File outputFile,
            long completedBeforeCurrent,
            long expectedTotal,
            Listener listener
    ) throws Exception {

        long existing = outputFile.exists() ? outputFile.length() : 0L;
        HttpURLConnection conn = openFollowingRedirects(spec.url, existing);
        int code = conn.getResponseCode();

        if (code == 416) {
            conn.disconnect();
            //noinspection ResultOfMethodCallIgnored
            outputFile.delete();
            existing = 0L;
            conn = openFollowingRedirects(spec.url, 0L);
            code = conn.getResponseCode();
        }

        boolean partial = code == HttpURLConnection.HTTP_PARTIAL;
        if (code != HttpURLConnection.HTTP_OK && !partial) {
            String msg = "HTTP " + code + " " + conn.getResponseMessage();
            conn.disconnect();
            throw new Exception(msg);
        }

        if (!partial && existing > 0L) {
            // Server mengabaikan Range. Mulai ulang supaya file tidak korup.
            existing = 0L;
        }

        try (InputStream in = new BufferedInputStream(conn.getInputStream(), 64 * 1024);
             FileOutputStream out = new FileOutputStream(outputFile, partial && existing > 0L)) {

            byte[] buffer = new byte[64 * 1024];
            long downloaded = existing;
            int read;
            int lastPercent = -1;

            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                downloaded += read;

                long weightedDone = completedBeforeCurrent + Math.min(downloaded, spec.expectedBytes);
                int percent = (int) Math.min(99L, weightedDone * 100L / expectedTotal);

                if (percent != lastPercent) {
                    listener.onProgress(name, percent, weightedDone, expectedTotal);
                    lastPercent = percent;
                }
            }
            out.flush();
        } finally {
            conn.disconnect();
        }
    }

    private HttpURLConnection openFollowingRedirects(String initialUrl, long existing) throws Exception {
        String current = initialUrl;

        for (int i = 0; i < 10; i++) {
            HttpURLConnection conn = (HttpURLConnection) new URL(current).openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(45_000);
            conn.setReadTimeout(120_000);
            conn.setRequestProperty("User-Agent", "FaceSwapLocal/1.0 Android");
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Accept-Encoding", "identity");

            if (existing > 0L) {
                conn.setRequestProperty("Range", "bytes=" + existing + "-");
            }

            int code = conn.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String location = conn.getHeaderField("Location");
                conn.disconnect();
                if (location == null || location.isEmpty()) {
                    throw new Exception("Redirect tanpa Location");
                }
                current = new URL(new URL(current), location).toString();
                continue;
            }
            return conn;
        }

        throw new Exception("Terlalu banyak redirect.");
    }
}
