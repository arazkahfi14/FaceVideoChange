package com.local.faceswapall;

import android.graphics.RectF;

public final class FaceInfo {
    public final RectF bbox;
    public final float[] landmarks;
    public final float score;

    public FaceInfo(RectF bbox, float[] landmarks, float score) {
        this.bbox = bbox;
        this.landmarks = landmarks;
        this.score = score;
    }

    public float area() {
        return Math.max(0f, bbox.width()) * Math.max(0f, bbox.height());
    }
}
