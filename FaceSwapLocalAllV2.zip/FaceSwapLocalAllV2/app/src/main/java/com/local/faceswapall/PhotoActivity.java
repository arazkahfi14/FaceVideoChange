package com.local.faceswapall;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.checkbox.MaterialCheckBox;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PhotoActivity extends AppCompatActivity {

    private static final int REQ_SOURCE = 1001;
    private static final int REQ_TARGET = 1002;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private ModelManager models;

    private Uri sourceUri;
    private Uri targetUri;
    private Bitmap resultBitmap;

    private TextView txtModelStatus;
    private TextView txtDownloadDetail;
    private ProgressBar modelProgress;
    private Button btnModel;
    private Button btnDeleteModel;
    private Button btnSource;
    private Button btnTarget;
    private Button btnSwap;
    private Button btnSave;
    private ImageView imgSource;
    private ImageView imgTarget;
    private ImageView imgResult;
    private TextView txtResultLabel;
    private TextView txtStatus;
    private MaterialCheckBox checkQuality;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        models = new ModelManager(this);
        bindViews();
        bindActions();
        refreshModelUi();
    }

    private void bindViews() {
        txtModelStatus = findViewById(R.id.txtModelStatus);
        txtDownloadDetail = findViewById(R.id.txtDownloadDetail);
        modelProgress = findViewById(R.id.modelProgress);
        btnModel = findViewById(R.id.btnModel);
        btnDeleteModel = findViewById(R.id.btnDeleteModel);
        btnSource = findViewById(R.id.btnSource);
        btnTarget = findViewById(R.id.btnTarget);
        btnSwap = findViewById(R.id.btnSwap);
        btnSave = findViewById(R.id.btnSave);
        imgSource = findViewById(R.id.imgSource);
        imgTarget = findViewById(R.id.imgTarget);
        imgResult = findViewById(R.id.imgResult);
        txtResultLabel = findViewById(R.id.txtResultLabel);
        txtStatus = findViewById(R.id.txtStatus);
        checkQuality = findViewById(R.id.checkQuality);
    }

    private void bindActions() {
        btnModel.setOnClickListener(v -> downloadModels());
        btnDeleteModel.setOnClickListener(v -> {
            models.deleteAll();
            refreshModelUi();
            Toast.makeText(this, "Model dihapus.", Toast.LENGTH_SHORT).show();
        });

        btnSource.setOnClickListener(v -> chooseImage(REQ_SOURCE));
        btnTarget.setOnClickListener(v -> chooseImage(REQ_TARGET));
        btnSwap.setOnClickListener(v -> runSwap());
        btnSave.setOnClickListener(v -> saveResult());
    }

    private void chooseImage(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        try {
            getContentResolver().takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        if (requestCode == REQ_SOURCE) {
            sourceUri = uri;
            imgSource.setImageURI(uri);
        } else if (requestCode == REQ_TARGET) {
            targetUri = uri;
            imgTarget.setImageURI(uri);
        }
        refreshSwapButton();
    }

    private void refreshModelUi() {
        boolean ready = models.isReady();

        if (ready) {
            long mb = models.currentBytes() / (1024L * 1024L);
            txtModelStatus.setText("✓ Model AI siap (" + mb + " MB)");
            txtDownloadDetail.setVisibility(View.GONE);
            modelProgress.setVisibility(View.GONE);
            btnModel.setVisibility(View.GONE);
            btnDeleteModel.setVisibility(View.VISIBLE);
        } else {
            long mb = models.currentBytes() / (1024L * 1024L);
            txtModelStatus.setText("Model AI belum lengkap");
            txtDownloadDetail.setText(mb > 0
                    ? "Sudah tersimpan " + mb + " MB. Download bisa dilanjutkan."
                    : "Download pertama ±740 MB. Disarankan pakai Wi-Fi.");
            txtDownloadDetail.setVisibility(View.VISIBLE);
            btnModel.setVisibility(View.VISIBLE);
            btnModel.setEnabled(true);
            btnDeleteModel.setVisibility(mb > 0 ? View.VISIBLE : View.GONE);
            modelProgress.setVisibility(View.GONE);
        }

        refreshSwapButton();
    }

    private void refreshSwapButton() {
        btnSwap.setEnabled(models.isReady() && sourceUri != null && targetUri != null);
    }

    private void downloadModels() {
        btnModel.setEnabled(false);
        btnDeleteModel.setEnabled(false);
        modelProgress.setVisibility(View.VISIBLE);
        txtDownloadDetail.setVisibility(View.VISIBLE);
        txtModelStatus.setText("Mengunduh model AI...");

        executor.execute(() -> models.downloadAll(new ModelManager.Listener() {
            @Override
            public void onProgress(String fileName, int overallPercent, long doneBytes, long totalBytes) {
                runOnUiThread(() -> {
                    modelProgress.setProgress(overallPercent);
                    txtDownloadDetail.setText(
                            friendlyName(fileName) + " • " + overallPercent + "% • " +
                            mb(doneBytes) + " / " + mb(totalBytes) + " MB");
                });
            }

            @Override
            public void onComplete() {
                runOnUiThread(() -> {
                    btnDeleteModel.setEnabled(true);
                    Toast.makeText(PhotoActivity.this, "Model siap. Setelah ini bisa offline.", Toast.LENGTH_LONG).show();
                    refreshModelUi();
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    btnModel.setEnabled(true);
                    btnDeleteModel.setEnabled(true);
                    txtModelStatus.setText("Download gagal");
                    txtDownloadDetail.setText(message + "\nTekan Download Model AI untuk melanjutkan.");
                });
            }
        }));
    }

    private void runSwap() {
        if (!models.isReady()) {
            Toast.makeText(this, "Download model AI dulu.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (sourceUri == null || targetUri == null) {
            Toast.makeText(this, "Pilih foto wajah dan foto target.", Toast.LENGTH_SHORT).show();
            return;
        }

        btnSwap.setEnabled(false);
        btnSource.setEnabled(false);
        btnTarget.setEnabled(false);
        btnSave.setVisibility(View.GONE);
        txtStatus.setText("Menyiapkan foto...");

        final int maxDimension = checkQuality.isChecked() ? 2048 : 1280;

        executor.execute(() -> {
            Bitmap source = null;
            Bitmap target = null;
            try {
                source = ImageLoader.load(this, sourceUri, maxDimension);
                target = ImageLoader.load(this, targetUri, maxDimension);

                FaceSwapEngine engine = new FaceSwapEngine(models);
                Bitmap finalResult = engine.swap(source, target,
                        status -> runOnUiThread(() -> txtStatus.setText(status)));

                if (resultBitmap != null && !resultBitmap.isRecycled()) {
                    resultBitmap.recycle();
                }
                resultBitmap = finalResult;

                runOnUiThread(() -> {
                    imgResult.setImageBitmap(resultBitmap);
                    imgResult.setVisibility(View.VISIBLE);
                    txtResultLabel.setVisibility(View.VISIBLE);
                    btnSave.setVisibility(View.VISIBLE);
                    txtStatus.setText("✓ Selesai. Hasil belum disimpan.");
                });

            } catch (Exception e) {
                String message = e.getMessage() != null ? e.getMessage() : e.toString();
                runOnUiThread(() -> {
                    txtStatus.setText("Gagal: " + message);
                    Toast.makeText(PhotoActivity.this, "Face swap gagal", Toast.LENGTH_SHORT).show();
                });
            } finally {
                if (source != null && source != resultBitmap && !source.isRecycled()) source.recycle();
                if (target != null && target != resultBitmap && !target.isRecycled()) target.recycle();

                runOnUiThread(() -> {
                    btnSource.setEnabled(true);
                    btnTarget.setEnabled(true);
                    refreshSwapButton();
                });
            }
        });
    }

    private void saveResult() {
        if (resultBitmap == null) return;

        executor.execute(() -> {
            try {
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "FaceSwap_" + stamp + ".jpg");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceSwapLocal");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                if (uri == null) throw new IllegalStateException("Tidak bisa membuat file di galeri.");

                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null || !resultBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)) {
                        throw new IllegalStateException("Gagal menulis JPG.");
                    }
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);

                runOnUiThread(() -> Toast.makeText(
                        PhotoActivity.this,
                        "Tersimpan di Pictures/FaceSwapLocal",
                        Toast.LENGTH_LONG).show());

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        PhotoActivity.this,
                        "Gagal simpan: " + (e.getMessage() != null ? e.getMessage() : e.toString()),
                        Toast.LENGTH_LONG).show());
            }
        });
    }

    private static long mb(long bytes) {
        return Math.max(0L, bytes / (1024L * 1024L));
    }

    private static String friendlyName(String file) {
        if (ModelManager.DETECTOR.equals(file)) return "Detector";
        if (ModelManager.EMBEDDER.equals(file)) return "ArcFace";
        if (ModelManager.SWAPPER.equals(file)) return "INSwapper";
        if (ModelManager.EMAP.equals(file)) return "EMAP";
        return file;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        if (resultBitmap != null && !resultBitmap.isRecycled()) {
            resultBitmap.recycle();
        }
    }
}
