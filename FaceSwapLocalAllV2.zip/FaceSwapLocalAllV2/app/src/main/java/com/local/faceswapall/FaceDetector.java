package com.local.faceswapall;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;

import java.lang.reflect.Array;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;

public final class FaceDetector implements AutoCloseable {

    private static final int INPUT = 640;
    private final OrtEnvironment env = OrtEnvironment.getEnvironment();
    private OrtSession session;

    public FaceDetector(ModelManager models) throws Exception {
        session = OrtUtils.createSession(env, models.getFile(ModelManager.DETECTOR).getAbsolutePath());
    }

    public List<FaceInfo> detect(Bitmap bitmap) throws Exception {
        float scale = Math.min((float) INPUT / bitmap.getWidth(), (float) INPUT / bitmap.getHeight());
        int newW = Math.max(1, Math.round(bitmap.getWidth() * scale));
        int newH = Math.max(1, Math.round(bitmap.getHeight() * scale));

        Bitmap padded = Bitmap.createBitmap(INPUT, INPUT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(padded);
        canvas.drawColor(0xFF000000);
        Bitmap resized = Bitmap.createScaledBitmap(bitmap, newW, newH, true);
        canvas.drawBitmap(resized, 0f, 0f, null);

        float[] chw = rgbChw(padded, 127.5f, 128f);
        OnnxTensor input = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(chw), new long[]{1, 3, INPUT, INPUT});

        String inputName = session.getInputNames().iterator().next();
        OrtSession.Result result = session.run(Collections.singletonMap(inputName, input));

        List<FaceInfo> faces = decodeScrfd(result, scale, 0.50f);
        if (faces.isEmpty()) {
            faces = decodeScrfd(result, scale, 0.30f);
        }

        result.close();
        input.close();
        if (resized != bitmap) resized.recycle();
        padded.recycle();

        return nms(faces, 0.40f);
    }

    public FaceInfo largest(Bitmap bitmap) throws Exception {
        List<FaceInfo> faces = detect(bitmap);
        if (faces.isEmpty()) return null;
        return Collections.max(faces, Comparator.comparingDouble(FaceInfo::area));
    }

    private List<FaceInfo> decodeScrfd(OrtSession.Result result, float scale, float threshold) throws Exception {
        if (result.size() < 9) {
            throw new IllegalStateException(
                    "Detector menghasilkan " + result.size() + " output. V1 mengharapkan SCRFD 9-output.");
        }

        int[] strides = {8, 16, 32};
        List<FaceInfo> out = new ArrayList<>();

        for (int level = 0; level < 3; level++) {
            int stride = strides[level];
            int featW = INPUT / stride;
            int featH = INPUT / stride;
            int anchors = 2;
            int candidates = featW * featH * anchors;

            float[] scores = flatten(result.get(level).getValue());
            float[] boxes = flatten(result.get(level + 3).getValue());
            float[] kps = flatten(result.get(level + 6).getValue());

            for (int i = 0; i < candidates; i++) {
                float score;
                if (scores.length >= candidates * 2) {
                    score = scores[i * 2 + 1];
                } else if (i < scores.length) {
                    score = scores[i];
                } else {
                    break;
                }

                if (score < threshold) continue;
                if (i * 4 + 3 >= boxes.length || i * 10 + 9 >= kps.length) continue;

                int pos = i / anchors;
                int x = pos % featW;
                int y = pos / featW;
                float cx = x * stride;
                float cy = y * stride;

                float left = boxes[i * 4] * stride;
                float top = boxes[i * 4 + 1] * stride;
                float right = boxes[i * 4 + 2] * stride;
                float bottom = boxes[i * 4 + 3] * stride;

                RectF bbox = new RectF(
                        clamp((cx - left) / scale, 0f, Float.MAX_VALUE),
                        clamp((cy - top) / scale, 0f, Float.MAX_VALUE),
                        (cx + right) / scale,
                        (cy + bottom) / scale
                );

                float[] lm = new float[10];
                for (int p = 0; p < 5; p++) {
                    lm[p * 2] = (cx + kps[i * 10 + p * 2] * stride) / scale;
                    lm[p * 2 + 1] = (cy + kps[i * 10 + p * 2 + 1] * stride) / scale;
                }
                out.add(new FaceInfo(bbox, lm, score));
            }
        }
        return out;
    }

    private static float[] rgbChw(Bitmap bitmap, float mean, float std) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int count = w * h;
        int[] px = new int[count];
        bitmap.getPixels(px, 0, w, 0, 0, w, h);

        float[] data = new float[count * 3];
        for (int i = 0; i < count; i++) {
            int c = px[i];
            int r = (c >> 16) & 255;
            int g = (c >> 8) & 255;
            int b = c & 255;
            data[i] = (r - mean) / std;
            data[count + i] = (g - mean) / std;
            data[count * 2 + i] = (b - mean) / std;
        }
        return data;
    }

    private static float[] flatten(Object value) {
        ArrayList<Float> list = new ArrayList<>();
        flattenInto(value, list);
        float[] out = new float[list.size()];
        for (int i = 0; i < out.length; i++) out[i] = list.get(i);
        return out;
    }

    private static void flattenInto(Object value, List<Float> out) {
        if (value == null) return;
        Class<?> c = value.getClass();
        if (!c.isArray()) {
            if (value instanceof Number) out.add(((Number) value).floatValue());
            return;
        }
        int len = Array.getLength(value);
        for (int i = 0; i < len; i++) {
            Object item = Array.get(value, i);
            flattenInto(item, out);
        }
    }

    private static List<FaceInfo> nms(List<FaceInfo> input, float iouThreshold) {
        List<FaceInfo> sorted = new ArrayList<>(input);
        sorted.sort((a, b) -> Float.compare(b.score, a.score));
        List<FaceInfo> kept = new ArrayList<>();

        for (FaceInfo candidate : sorted) {
            boolean suppress = false;
            for (FaceInfo existing : kept) {
                if (iou(candidate.bbox, existing.bbox) > iouThreshold) {
                    suppress = true;
                    break;
                }
            }
            if (!suppress) kept.add(candidate);
        }
        return kept;
    }

    private static float iou(RectF a, RectF b) {
        float left = Math.max(a.left, b.left);
        float top = Math.max(a.top, b.top);
        float right = Math.min(a.right, b.right);
        float bottom = Math.min(a.bottom, b.bottom);
        float iw = Math.max(0f, right - left);
        float ih = Math.max(0f, bottom - top);
        float inter = iw * ih;
        float union = Math.max(1f, a.width() * a.height() + b.width() * b.height() - inter);
        return inter / union;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void close() {
        if (session != null) {
            try { session.close(); } catch (Exception ignored) {}
            session = null;
        }
    }
}
