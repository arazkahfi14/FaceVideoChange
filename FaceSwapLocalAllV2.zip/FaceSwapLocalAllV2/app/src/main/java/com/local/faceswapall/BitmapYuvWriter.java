package com.local.faceswapall;

import android.graphics.Bitmap;
import android.media.Image;

import java.nio.ByteBuffer;

public final class BitmapYuvWriter {
    private BitmapYuvWriter() {}

    public static void write(Bitmap bitmap, Image image) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        Image.Plane[] planes = image.getPlanes();
        if (planes.length < 3) throw new IllegalStateException("Encoder tidak menyediakan 3 plane YUV.");

        writeY(pixels, width, height, planes[0]);
        writeUV(pixels, width, height, planes[1], planes[2]);
    }

    private static void writeY(int[] pixels, int width, int height, Image.Plane plane) {
        ByteBuffer b = plane.getBuffer();
        int base = b.position();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int c = pixels[y * width + x];
                int r = (c >> 16) & 255;
                int g = (c >> 8) & 255;
                int bl = c & 255;
                int yy = clamp(((66 * r + 129 * g + 25 * bl + 128) >> 8) + 16);
                int index = base + y * rowStride + x * pixelStride;
                if (index < b.limit()) b.put(index, (byte) yy);
            }
        }
    }

    private static void writeUV(int[] pixels, int width, int height, Image.Plane uPlane, Image.Plane vPlane) {
        ByteBuffer ub = uPlane.getBuffer();
        ByteBuffer vb = vPlane.getBuffer();
        int uBase = ub.position();
        int vBase = vb.position();
        int uRow = uPlane.getRowStride();
        int vRow = vPlane.getRowStride();
        int uPix = uPlane.getPixelStride();
        int vPix = vPlane.getPixelStride();

        for (int y = 0; y < height; y += 2) {
            for (int x = 0; x < width; x += 2) {
                int sumR = 0, sumG = 0, sumB = 0, n = 0;
                for (int dy = 0; dy < 2; dy++) {
                    for (int dx = 0; dx < 2; dx++) {
                        int px = x + dx;
                        int py = y + dy;
                        if (px >= width || py >= height) continue;
                        int c = pixels[py * width + px];
                        sumR += (c >> 16) & 255;
                        sumG += (c >> 8) & 255;
                        sumB += c & 255;
                        n++;
                    }
                }
                int r = sumR / Math.max(1, n);
                int g = sumG / Math.max(1, n);
                int bl = sumB / Math.max(1, n);
                int u = clamp(((-38 * r - 74 * g + 112 * bl + 128) >> 8) + 128);
                int v = clamp(((112 * r - 94 * g - 18 * bl + 128) >> 8) + 128);

                int cx = x / 2;
                int cy = y / 2;
                int ui = uBase + cy * uRow + cx * uPix;
                int vi = vBase + cy * vRow + cx * vPix;
                if (ui < ub.limit()) ub.put(ui, (byte) u);
                if (vi < vb.limit()) vb.put(vi, (byte) v);
            }
        }
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}
