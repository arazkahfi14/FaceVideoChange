package com.local.faceswapall;

import android.graphics.Bitmap;

public final class FaceSwapEngine {

    public interface StatusListener {
        void onStatus(String status);
    }

    private final ModelManager models;

    public FaceSwapEngine(ModelManager models) {
        this.models = models;
    }

    public Bitmap swap(Bitmap source, Bitmap target, StatusListener listener) throws Exception {
        if (!models.isReady()) {
            throw new IllegalStateException("Model AI belum lengkap.");
        }

        FaceInfo sourceFace;
        FaceInfo targetFace;

        listener.onStatus("Mendeteksi wajah...");
        try (FaceDetector detector = new FaceDetector(models)) {
            sourceFace = detector.largest(source);
            targetFace = detector.largest(target);
        }

        if (sourceFace == null) {
            throw new IllegalStateException("Wajah pada foto sumber tidak ditemukan.");
        }
        if (targetFace == null) {
            throw new IllegalStateException("Wajah pada foto target tidak ditemukan.");
        }

        FaceAligner.Alignment sourceAligned = FaceAligner.align(source, sourceFace, 112);
        FaceAligner.Alignment targetAligned = FaceAligner.align(target, targetFace, 128);

        listener.onStatus("Membaca identitas wajah...");
        float[] embedding;
        try (FaceEmbedder embedder = new FaceEmbedder(models)) {
            embedding = embedder.embedding(sourceAligned.bitmap);
        }

        listener.onStatus("Menukar wajah...");
        Bitmap swapped;
        try (FaceSwapper swapper = new FaceSwapper(models)) {
            swapped = swapper.swap(targetAligned.bitmap, embedding);
        }

        listener.onStatus("Menyatukan hasil...");
        Bitmap result = ImageBlender.blend(target, swapped, targetAligned.sourceToCrop);

        sourceAligned.bitmap.recycle();
        targetAligned.bitmap.recycle();
        swapped.recycle();

        return result;
    }
}
