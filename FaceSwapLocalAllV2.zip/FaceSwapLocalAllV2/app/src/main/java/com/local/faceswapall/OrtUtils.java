package com.local.faceswapall;

import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

public final class OrtUtils {
    private OrtUtils() {}

    public static OrtSession createSession(OrtEnvironment env, String path) throws OrtException {
        OrtSession.SessionOptions options = new OrtSession.SessionOptions();
        int cpu = Runtime.getRuntime().availableProcessors();
        int threads = Math.max(2, Math.min(4, cpu - 1));
        options.setIntraOpNumThreads(threads);
        options.setInterOpNumThreads(1);
        options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
        return env.createSession(path, options);
    }
}
