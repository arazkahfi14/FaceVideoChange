package com.local.faceswapall;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class VideoProcessingService extends Service {
    public static final String ACTION_START = "com.local.faceswapall.action.START_VIDEO_SWAP";
    public static final String ACTION_CANCEL = "com.local.faceswapall.action.CANCEL_VIDEO_SWAP";
    public static final String ACTION_PROGRESS = "com.local.faceswapall.action.VIDEO_PROGRESS";

    public static final String EXTRA_SOURCE_URI = "source_uri";
    public static final String EXTRA_VIDEO_URI = "video_uri";
    public static final String EXTRA_START_US = "start_us";
    public static final String EXTRA_END_US = "end_us";
    public static final String EXTRA_QUALITY = "quality";
    public static final String EXTRA_PROGRESS = "progress";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_RUNNING = "running";
    public static final String EXTRA_RESULT_URI = "result_uri";

    private static final String PREFS = "video_job_state";
    private static final String CHANNEL_ID = "faceswap_video_processing";
    private static final int NOTIFICATION_ID = 4102;

    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private ExecutorService executor;
    private volatile boolean running = false;
    private int lastNotificationProgress = -1;
    private PowerManager.WakeLock wakeLock;

    public static final class JobState {
        public final boolean running;
        public final int progress;
        public final String status;
        public final String resultUri;

        JobState(boolean running, int progress, String status, String resultUri) {
            this.running = running;
            this.progress = progress;
            this.status = status;
            this.resultUri = resultUri;
        }
    }

    public static JobState readState(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return new JobState(
                p.getBoolean("running", false),
                p.getInt("progress", 0),
                p.getString("status", "Siap"),
                p.getString("result_uri", "")
        );
    }

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newSingleThreadExecutor();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_CANCEL.equals(action)) {
            cancelled.set(true);
            updateState(true, readState(this).progress, "Membatalkan setelah frame aktif selesai...", "");
            updateNotification(readState(this).progress, "Membatalkan proses...");
            return START_NOT_STICKY;
        }

        if (!ACTION_START.equals(action) || running) return START_NOT_STICKY;

        String source = intent.getStringExtra(EXTRA_SOURCE_URI);
        String video = intent.getStringExtra(EXTRA_VIDEO_URI);
        long startUs = intent.getLongExtra(EXTRA_START_US, 0L);
        long endUs = intent.getLongExtra(EXTRA_END_US, 0L);
        boolean quality = intent.getBooleanExtra(EXTRA_QUALITY, false);

        if (source == null || video == null || endUs <= startUs) {
            updateState(false, 0, "Parameter video tidak valid.", "");
            stopSelf();
            return START_NOT_STICKY;
        }

        cancelled.set(false);
        running = true;
        lastNotificationProgress = -1;
        updateState(true, 0, "Menyiapkan video...", "");
        startForegroundNow(0, "Menyiapkan video...");
        acquireWakeLock();

        executor.execute(() -> processJob(Uri.parse(source), Uri.parse(video), startUs, endUs, quality));
        return START_NOT_STICKY;
    }

    private void processJob(Uri sourceUri, Uri videoUri, long startUs, long endUs, boolean quality) {
        File temp = null;
        try {
            ModelManager models = new ModelManager(this);
            if (!models.isReady()) throw new IllegalStateException("Model AI belum lengkap.");

            temp = VideoFaceSwapProcessor.process(
                    this,
                    sourceUri,
                    videoUri,
                    models,
                    startUs,
                    endUs,
                    quality,
                    cancelled,
                    new VideoFaceSwapProcessor.Callback() {
                        @Override
                        public void onStatus(String status) {
                            JobState current = readState(VideoProcessingService.this);
                            updateState(true, current.progress, status, "");
                            if (current.progress != lastNotificationProgress) {
                                updateNotification(current.progress, status);
                            }
                        }

                        @Override
                        public void onProgress(int percent, int frame, int totalFrames) {
                            String status = "Memproses " + percent + "% • frame " + frame + "/" + totalFrames;
                            updateState(true, percent, status, "");
                            if (percent >= lastNotificationProgress + 2 || percent == 100) {
                                lastNotificationProgress = percent;
                                updateNotification(percent, status);
                            }
                        }
                    }
            );

            if (cancelled.get()) throw new InterruptedException("Proses dibatalkan.");
            Uri saved = saveToGallery(temp);
            updateState(false, 100, "✓ Selesai dan tersimpan.", saved.toString());
            showFinishedNotification(saved);

        } catch (InterruptedException e) {
            updateState(false, 0, "Proses dibatalkan.", "");
        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage() : e.toString();
            updateState(false, 0, "Gagal: " + msg, "");
            showErrorNotification(msg);
        } finally {
            if (temp != null && temp.exists()) temp.delete();
            running = false;
            releaseWakeLock();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    private Uri saveToGallery(File file) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "FaceSwapVideo_" + stamp + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FaceSwapLocal");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);

        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Tidak bisa membuat file video di galeri.");

        try (FileInputStream in = new FileInputStream(file);
             OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Tidak bisa membuka output galeri.");
            byte[] buffer = new byte[128 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            throw e;
        }

        ContentValues done = new ContentValues();
        done.put(MediaStore.Video.Media.IS_PENDING, 0);
        getContentResolver().update(uri, done, null, null);
        return uri;
    }


    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FaceSwapLocal:VideoProcessing");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(60L * 60L * 1000L);
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void updateState(boolean isRunning, int progress, String status, String resultUri) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("running", isRunning)
                .putInt("progress", progress)
                .putString("status", status == null ? "" : status)
                .putString("result_uri", resultUri == null ? "" : resultUri)
                .apply();

        Intent update = new Intent(ACTION_PROGRESS);
        update.setPackage(getPackageName());
        update.putExtra(EXTRA_RUNNING, isRunning);
        update.putExtra(EXTRA_PROGRESS, progress);
        update.putExtra(EXTRA_STATUS, status);
        update.putExtra(EXTRA_RESULT_URI, resultUri);
        sendBroadcast(update);
    }

    private void createNotificationChannel() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Pemrosesan FaceSwap Video",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Menjaga proses face swap video tetap berjalan saat aplikasi diminimalkan.");
        manager.createNotificationChannel(channel);
    }

    private PendingIntent openAppIntent() {
        Intent i = new Intent(this, VideoActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 91, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent cancelIntent() {
        Intent i = new Intent(this, VideoProcessingService.class);
        i.setAction(ACTION_CANCEL);
        return PendingIntent.getService(this, 92, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildProgressNotification(int progress, String status) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("FaceSwap Video berjalan")
                .setContentText(status)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setContentIntent(openAppIntent())
                .setProgress(100, Math.max(0, Math.min(100, progress)), progress <= 0)
                .addAction(0, "Batalkan", cancelIntent())
                .build();
    }

    private void startForegroundNow(int progress, String status) {
        Notification notification = buildProgressNotification(progress, status);
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING);
    }

    private void updateNotification(int progress, String status) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, buildProgressNotification(progress, status));
    }

    private void showFinishedNotification(Uri saved) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("FaceSwap Video selesai")
                .setContentText("Video sudah disimpan ke Movies/FaceSwapLocal")
                .setAutoCancel(true)
                .setContentIntent(openAppIntent())
                .build();
        manager.notify(NOTIFICATION_ID + 1, n);
    }

    private void showErrorNotification(String message) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("FaceSwap Video gagal")
                .setContentText(message)
                .setAutoCancel(true)
                .setContentIntent(openAppIntent())
                .build();
        manager.notify(NOTIFICATION_ID + 2, n);
    }

    @Override
    public void onTimeout(int startId, int fgsType) {
        cancelled.set(true);
        updateState(false, readState(this).progress, "Dihentikan Android karena batas waktu pemrosesan latar belakang.", "");
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        cancelled.set(true);
        releaseWakeLock();
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }
}
