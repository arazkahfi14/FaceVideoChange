package com.local.faceswapall;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;

import androidx.exifinterface.media.ExifInterface;

import java.io.InputStream;

public final class ImageLoader {
    private ImageLoader() {}

    public static Bitmap load(Context context, Uri uri, int maxDimension) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;

        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Tidak bisa membuka gambar.");
            BitmapFactory.decodeStream(in, null, bounds);
        }

        int sample = 1;
        int largest = Math.max(bounds.outWidth, bounds.outHeight);
        while (largest / sample > maxDimension * 2) {
            sample *= 2;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;

        Bitmap bitmap;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Tidak bisa membuka gambar.");
            bitmap = BitmapFactory.decodeStream(in, null, options);
        }

        if (bitmap == null) throw new IllegalStateException("Format gambar tidak bisa dibaca.");
        bitmap = rotateExif(context, uri, bitmap);

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int max = Math.max(w, h);
        if (max > maxDimension) {
            float scale = maxDimension / (float) max;
            int nw = Math.max(1, Math.round(w * scale));
            int nh = Math.max(1, Math.round(h * scale));
            Bitmap resized = Bitmap.createScaledBitmap(bitmap, nw, nh, true);
            if (resized != bitmap) bitmap.recycle();
            bitmap = resized;
        }

        if (bitmap.getConfig() != Bitmap.Config.ARGB_8888) {
            Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
            bitmap.recycle();
            bitmap = copy;
        }

        return bitmap;
    }

    private static Bitmap rotateExif(Context context, Uri uri, Bitmap src) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) return src;
            ExifInterface exif = new ExifInterface(in);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
            );

            float angle;
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90: angle = 90f; break;
                case ExifInterface.ORIENTATION_ROTATE_180: angle = 180f; break;
                case ExifInterface.ORIENTATION_ROTATE_270: angle = 270f; break;
                default: return src;
            }

            Matrix m = new Matrix();
            m.postRotate(angle);
            Bitmap rotated = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
            if (rotated != src) src.recycle();
            return rotated;
        } catch (Exception ignored) {
            return src;
        }
    }
}
