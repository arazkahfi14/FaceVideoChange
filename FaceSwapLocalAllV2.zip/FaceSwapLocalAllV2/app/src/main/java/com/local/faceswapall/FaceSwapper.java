package com.local.faceswapall;

import android.graphics.Bitmap;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;

import ai.onnxruntime.NodeInfo;
import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.TensorInfo;

public final class FaceSwapper implements AutoCloseable {

    private static final int SIZE = 128;
    private final OrtEnvironment env = OrtEnvironment.getEnvironment();
    private OrtSession session;
    private final float[][] emap;
    private String imageInput;
    private String embeddingInput;

    public FaceSwapper(ModelManager models) throws Exception {
        session = OrtUtils.createSession(env, models.getFile(ModelManager.SWAPPER).getAbsolutePath());
        resolveInputs();
        emap = loadEmap(models.getFile(ModelManager.EMAP).getAbsolutePath());
    }

    private void resolveInputs() throws Exception {
        for (Map.Entry<String, NodeInfo> e : session.getInputInfo().entrySet()) {
            if (!(e.getValue().getInfo() instanceof TensorInfo)) continue;
            long[] shape = ((TensorInfo) e.getValue().getInfo()).getShape();
            if (shape.length == 4) imageInput = e.getKey();
            else if (shape.length == 2) embeddingInput = e.getKey();
        }
        if (imageInput == null || embeddingInput == null) {
            throw new IllegalStateException("Input INSwapper tidak dikenali.");
        }
    }

    public Bitmap swap(Bitmap targetAligned, float[] sourceEmbedding) throws Exception {
        Bitmap face = targetAligned.getWidth() == SIZE && targetAligned.getHeight() == SIZE
                ? targetAligned
                : Bitmap.createScaledBitmap(targetAligned, SIZE, SIZE, true);

        int count = SIZE * SIZE;
        int[] pixels = new int[count];
        face.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE);

        float[] image = new float[count * 3];
        for (int i = 0; i < count; i++) {
            int c = pixels[i];
            image[i] = ((c >> 16) & 255) / 255f;
            image[count + i] = ((c >> 8) & 255) / 255f;
            image[count * 2 + i] = (c & 255) / 255f;
        }

        float[] latent = transform(sourceEmbedding);

        OnnxTensor imageTensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(image), new long[]{1, 3, SIZE, SIZE});
        OnnxTensor embeddingTensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(latent), new long[]{1, latent.length});

        Map<String, OnnxTensor> inputs = new HashMap<>();
        inputs.put(imageInput, imageTensor);
        inputs.put(embeddingInput, embeddingTensor);

        OrtSession.Result result = session.run(inputs);
        float[][][][] out = (float[][][][]) result.get(0).getValue();
        Bitmap bitmap = toBitmap(out[0]);

        result.close();
        imageTensor.close();
        embeddingTensor.close();
        if (face != targetAligned) face.recycle();

        return bitmap;
    }

    private float[] transform(float[] embedding) {
        if (embedding.length != 512) {
            throw new IllegalArgumentException("Embedding harus 512 dimensi.");
        }
        float[] result = new float[512];

        for (int col = 0; col < 512; col++) {
            float sum = 0f;
            for (int row = 0; row < 512; row++) {
                sum += embedding[row] * emap[row][col];
            }
            result[col] = sum;
        }

        float norm = 0f;
        for (float v : result) norm += v * v;
        norm = (float) Math.sqrt(norm);
        if (norm > 0f) {
            for (int i = 0; i < result.length; i++) result[i] /= norm;
        }
        return result;
    }

    private static Bitmap toBitmap(float[][][] chw) {
        int h = chw[0].length;
        int w = chw[0][0].length;
        int[] pixels = new int[w * h];

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = clamp255(chw[0][y][x] * 255f);
                int g = clamp255(chw[1][y][x] * 255f);
                int b = clamp255(chw[2][y][x] * 255f);
                pixels[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }

        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(pixels, 0, w, 0, 0, w, h);
        return out;
    }

    private static int clamp255(float v) {
        return Math.max(0, Math.min(255, Math.round(v)));
    }

    private static float[][] loadEmap(String path) throws Exception {
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(path))) {
            byte[] header = readExactly(in, 8);
            ByteBuffer h = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
            int rows = h.getInt();
            int cols = h.getInt();

            if (rows != 512 || cols != 512) {
                throw new IllegalStateException("emap.bin invalid: " + rows + "x" + cols);
            }

            byte[] bytes = readExactly(in, rows * cols * 4);
            ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            float[][] out = new float[rows][cols];
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    out[r][c] = b.getFloat();
                }
            }
            return out;
        }
    }

    private static byte[] readExactly(BufferedInputStream in, int size) throws Exception {
        byte[] data = new byte[size];
        int read = 0;
        while (read < size) {
            int n = in.read(data, read, size - read);
            if (n < 0) throw new IllegalStateException("File terpotong.");
            read += n;
        }
        return data;
    }

    @Override
    public void close() {
        if (session != null) {
            try { session.close(); } catch (Exception ignored) {}
            session = null;
        }
    }
}
