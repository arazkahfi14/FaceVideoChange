package com.local.faceswapall;

import android.graphics.Bitmap;

public final class VideoFaceSwapEngine implements AutoCloseable {
    private final FaceDetector detector;
    private final FaceSwapper swapper;
    private final float[] sourceEmbedding;

    public VideoFaceSwapEngine(ModelManager models, Bitmap source) throws Exception {
        if (!models.isReady()) throw new IllegalStateException("Model AI belum lengkap.");

        detector = new FaceDetector(models);
        FaceInfo sourceFace = detector.largest(source);
        if (sourceFace == null) {
            detector.close();
            throw new IllegalStateException("Wajah pada foto sumber tidak ditemukan.");
        }

        FaceAligner.Alignment aligned = FaceAligner.align(source, sourceFace, 112);
        try (FaceEmbedder embedder = new FaceEmbedder(models)) {
            sourceEmbedding = embedder.embedding(aligned.bitmap);
        } finally {
            aligned.bitmap.recycle();
        }

        swapper = new FaceSwapper(models);
    }

    public Bitmap processFrame(Bitmap frame) throws Exception {
        FaceInfo targetFace = detector.largest(frame);
        if (targetFace == null) {
            return frame;
        }

        FaceAligner.Alignment aligned = FaceAligner.align(frame, targetFace, 128);
        Bitmap swapped = null;
        try {
            swapped = swapper.swap(aligned.bitmap, sourceEmbedding);
            return ImageBlender.blend(frame, swapped, aligned.sourceToCrop);
        } finally {
            aligned.bitmap.recycle();
            if (swapped != null && !swapped.isRecycled()) swapped.recycle();
        }
    }

    @Override
    public void close() {
        try { detector.close(); } catch (Exception ignored) {}
        try { swapper.close(); } catch (Exception ignored) {}
    }
}
