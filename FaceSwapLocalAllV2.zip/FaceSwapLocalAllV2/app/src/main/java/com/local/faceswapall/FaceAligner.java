package com.local.faceswapall;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public final class FaceAligner {

    public static final class Alignment {
        public final Bitmap bitmap;
        public final Matrix sourceToCrop;

        Alignment(Bitmap bitmap, Matrix sourceToCrop) {
            this.bitmap = bitmap;
            this.sourceToCrop = sourceToCrop;
        }
    }

    private FaceAligner() {}

    public static Alignment align(Bitmap source, FaceInfo face, int size) {
        if (face == null || face.landmarks == null || face.landmarks.length < 10) {
            throw new IllegalArgumentException("Landmark wajah tidak lengkap.");
        }

        float mouthX = (face.landmarks[6] + face.landmarks[8]) * 0.5f;
        float mouthY = (face.landmarks[7] + face.landmarks[9]) * 0.5f;

        float[] src = {
                face.landmarks[0], face.landmarks[1],
                face.landmarks[2], face.landmarks[3],
                mouthX, mouthY
        };

        float xOffset = size == 128 ? 8f : 0f;
        float mouthDstX = ((41.5493f + 70.7299f) * 0.5f) + xOffset;
        float mouthDstY = ((92.3655f + 92.2041f) * 0.5f);

        float scale = size / 112f;
        if (size != 128) {
            // Untuk ukuran selain 112/128, skalakan template secara proporsional.
            xOffset = 0f;
        }

        float[] dst;
        if (size == 128) {
            dst = new float[]{
                    38.2946f + 8f, 51.6963f,
                    73.5318f + 8f, 51.5014f,
                    mouthDstX, mouthDstY
            };
        } else if (size == 112) {
            dst = new float[]{
                    38.2946f, 51.6963f,
                    73.5318f, 51.5014f,
                    (41.5493f + 70.7299f) * 0.5f,
                    (92.3655f + 92.2041f) * 0.5f
            };
        } else {
            dst = new float[]{
                    38.2946f * scale, 51.6963f * scale,
                    73.5318f * scale, 51.5014f * scale,
                    ((41.5493f + 70.7299f) * 0.5f) * scale,
                    ((92.3655f + 92.2041f) * 0.5f) * scale
            };
        }

        Matrix matrix = new Matrix();
        boolean ok = matrix.setPolyToPoly(src, 0, dst, 0, 3);
        if (!ok) {
            throw new IllegalStateException("Gagal menghitung alignment wajah.");
        }

        Bitmap aligned = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(aligned);
        canvas.drawColor(0xFF000000);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(source, matrix, paint);

        return new Alignment(aligned, matrix);
    }
}
