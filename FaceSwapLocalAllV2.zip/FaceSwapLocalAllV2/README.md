# FaceSwap Local All V2

Satu aplikasi Android native berisi dua mode:

- Face Swap Foto
- Face Swap Video

Keduanya memakai satu folder model AI yang sama di storage privat aplikasi. Model tidak dibundel ke APK; download sekali dari salah satu mode, lalu Foto dan Video memakai model yang sama.

## Background processing video

Video diproses oleh Android Foreground Service (`VideoProcessingService`) dengan tipe `mediaProcessing`.

Saat pengguna menekan Home / berpindah aplikasi:

- proses video tetap berjalan;
- progress tampil di notifikasi Android;
- tombol Batalkan tersedia di notifikasi dan layar Video;
- hasil otomatis disimpan ke `Movies/FaceSwapLocal`;
- ketika aplikasi dibuka lagi, progress/status dipulihkan.

Service memakai partial wake lock selama job aktif supaya CPU tidak langsung tidur saat layar mati. Android tetap dapat menghentikan proses pada kondisi ekstrem seperti force-stop, kehabisan memori berat, atau batas sistem foreground service.

## Video V1

- pilih foto wajah sumber;
- pilih video target;
- pilih titik mulai dan selesai sendiri;
- maksimum 30 detik per proses;
- Fast: 720px / 10fps;
- Quality: 960px / 15fps;
- audio asli dipertahankan jika decoder/encoder perangkat mendukung;
- output MP4 ke `Movies/FaceSwapLocal`.

## Foto

- pilih foto sumber;
- pilih foto target;
- Fast / Quality;
- simpan JPG ke `Pictures/FaceSwapLocal`.

## Build di GitHub

Upload `FaceSwapLocalAllV2.zip` ke repository, lalu simpan workflow sebagai:

`.github/workflows/build-all-apk.yml`

Jalankan **Actions > Build FaceSwap Local All APK > Run workflow**.

Artifact: `FaceSwapLocal-All-APK-V2`.

## Catatan model

Project menggunakan pipeline SCRFD + ArcFace + INSwapper/EMAP yang sama dengan V1 foto. Model pretrained memiliki ketentuan lisensi tersendiri; gunakan sesuai hak penggunaan model dan foto/video yang diproses.
